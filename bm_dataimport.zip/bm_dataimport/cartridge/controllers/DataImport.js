'use strict';

var server = require('server');
var attributeHelper = require('*/cartridge/scripts/helpers/attributeHelper');

server.get('Start', function (req, res, next) {
    res.render('dataimport/dashboard', {});
    next();
});

/**
 * Returns the live attribute definitions for a given object type as JSON.
 * Called by the dashboard UI via fetch() when the user selects an object type.
 *
 * Query params:
 *   objectType  - SFCC system object type ID (e.g. "Product", "CatalogCategory")
 */
server.get('GetAttributes', function (req, res, next) {
    var objectType = req.querystring.objectType;

    if (!objectType) {
        res.json({ error: 'objectType parameter is required' });
        return next();
    }

    try {
        var attributes = attributeHelper.getAttributeDefinitions(objectType);
        res.json({ attributes: attributes });
    } catch (e) {
        res.json({ error: e.message });
    }

    next();
});

module.exports = server.exports();
